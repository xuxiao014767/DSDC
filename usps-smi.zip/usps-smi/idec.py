# -*- coding: utf-8 -*-
from __future__ import print_function, division
import argparse
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.optim import Adam
from torch.utils.data import DataLoader
from torch.nn import Linear
from torch._C import *
from utils import MnistDataset, cluster_acc
from torch.autograd import Variable
import DPC
from sklearn.manifold import TSNE

class AE(nn.Module):

    def __init__(self, n_z):
        super(AE, self).__init__()

        # encoder
        self.enc_1 = nn.Conv2d(1, 32, kernel_size=5, stride=2, padding=2)
        self.enc_2 = nn.Conv2d(32, 64, kernel_size=5, stride=2, padding=2)
        self.enc_3 = nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1)

        self.z_layer = Linear(128*2*2, n_z)

        # decoder
        self.z_layer1 = Linear(n_z, 128*2*2)

        self.dec_1 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.dec_2 = nn.ConvTranspose2d(64, 32, kernel_size=5, stride=2,  padding=2, output_padding=1)
        self.x_bar_layer = nn.ConvTranspose2d(32, 1, kernel_size=5, stride=2, padding=2, output_padding=1)

    def forward(self, x):

        # encoder
        enc_h1 = F.relu(self.enc_1(x))
        enc_h2 = F.relu(self.enc_2(enc_h1))
        enc_h3 = F.relu(self.enc_3(enc_h2))

        f1 = enc_h3.view(enc_h3.size(0), -1)
        z = self.z_layer(f1)
        f2 = self.z_layer1(z)
        f3 = f2.view(x.size(0), 128, 2, 2)

        # decoder
        dec_h1 = F.relu(self.dec_1(f3))
        dec_h2 = F.relu(self.dec_2(dec_h1))
        x_bar = self.x_bar_layer(dec_h2)

        return x_bar, z

class IDEC(nn.Module):

    def __init__(self, n_z, n_clusters, alpha=1.0, pretrain_path='data/ae_mnist.pkl'):
        super(IDEC, self).__init__()
        self.alpha = alpha
        self.pretrain_path = pretrain_path

        self.ae = AE(n_z=n_z)
        # cluster layer
        self.cluster_layer = Parameter(torch.Tensor(n_clusters, n_z))
        torch.nn.init.xavier_normal_(self.cluster_layer.data)

    def pretrain(self, path=''):
        if path == '':
            pretrain_ae(self.ae)
        # load pretrain weights
        self.ae.load_state_dict(torch.load(self.pretrain_path))
        print('load pretrained ae from', path)

    def forward(self, x):
        x_bar, z = self.ae(x)

        tsne = TSNE(perplexity=30, n_components=2, init='pca', n_iter=5000)
        low_dim_embs = tsne.fit_transform(z.data.numpy())
        z = torch.from_numpy(low_dim_embs)
        # cluster
        q = 1.0 / (1.0 + torch.sum(torch.pow(z.unsqueeze(1) - self.cluster_layer, 2), 2) / self.alpha)
        q = q.pow((self.alpha + 1.0) / 2.0)
        q = (q.t() / torch.sum(q, 1)).t()
        return x_bar, q

def target_distribution(q):
    weight = q**2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()

def pretrain_ae(model):
    '''
    pretrain autoencoder
    '''
    train_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True)
    print(model)
    optimizer = Adam(model.parameters(), lr=args.lr)
    for epoch in range(200):
        total_loss = 0.
        for batch_idx, (x, _, _) in enumerate(train_loader):
            x = x.to(device)

            optimizer.zero_grad()
            x_bar, z = model(x)
            loss = F.mse_loss(x_bar, x)
            total_loss += loss.item()

            loss.backward()
            optimizer.step()

        print("epoch {} loss={:.4f}".format(epoch, total_loss / (batch_idx + 1)))
        torch.save(model.state_dict(), args.pretrain_path)
    print("model saved to {}.".format(args.pretrain_path))


def train_idec():

    model = IDEC(n_z=args.n_z, n_clusters=args.n_clusters, alpha=1.0, pretrain_path=args.pretrain_path).to(device)

    model.pretrain('data/ae_mnist.pkl')
    # model.pretrain()

    train_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False)

    y_labels = []
    idxx=[]
    for batch_idx, (x, y1, idx) in enumerate(train_loader):
        if batch_idx == 0 or batch_idx == 13:
            y1 = y1.type(torch.LongTensor).to(device)
            y_labels = np.hstack((y_labels, y1))
            idxx=np.hstack((idxx, idx))


    optimizer = Adam(model.parameters(), lr=args.lr)

    # cluster parameter initiate
    data = dataset.x
    y = dataset.y

    data = torch.Tensor(data).to(device)

    x_bar, z = model.ae(data)

    tsne = TSNE(perplexity=30, n_components=2, init='pca', n_iter=5000)
    low_dim_embs = tsne.fit_transform(z.data.numpy())

    clusterIndex, centers = DPC.fit(low_dim_embs, 2, 10, 20, y_labels, idxx)

    y_pred = clusterIndex

    y_pred_last = y_pred

    model.cluster_layer.data = torch.tensor(centers).to(device)

    model.train()
    for epoch in range(200):

        if epoch % args.update_interval == 0:

            _, tmp_q = model(data)

            # update target distribution p
            tmp_q = tmp_q.data

            # evaluate clustering performance
            y_pred = tmp_q.cpu().numpy().argmax(1)
            delta_label = np.sum(y_pred != y_pred_last).astype(np.float32) / y_pred.shape[0]
            y_pred_last = y_pred

            acc = cluster_acc(y, y_pred)
            nmi = nmi_score(y, y_pred)
            ari = ari_score(y, y_pred)
            print('Iter {}'.format(epoch), ':Acc {:.4f}'.format(acc), ', nmi {:.4f}'.format(nmi), ', ari {:.4f}'.format(ari))

            if epoch > 0 and delta_label < args.tol:
                print('delta_label {:.4f}'.format(delta_label), '< tol', args.tol)
                print('Reached tolerance threshold. Stopping training.')
                break

        for batch_idx, (x, y1, idx) in enumerate(train_loader):

            if batch_idx == 0 or batch_idx == 13:
                x = x.to(device)
                y1 = y1.type(torch.LongTensor).to(device)

                x_bar, q = model(x)

                class_num = 10
                batch_size = x.size(0)

                b = torch.zeros(batch_size, class_num).scatter_(1, y1.unsqueeze(1), 1)
                b = Variable(b, requires_grad=True)  #
                loss = F.mse_loss(q, b)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()


            elif batch_idx != 0 and batch_idx != 13:
                x = x.to(device)

                x_bar, q = model(x)

                tmp_q = q.data
                p = target_distribution(tmp_q)

                kl_loss = F.kl_div(q.log(), p)
                loss = kl_loss

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='train', formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--n_clusters', default=10, type=int)
    parser.add_argument('--batch_size', default=256, type=int)
    parser.add_argument('--n_z', default=10, type=int)
    parser.add_argument('--dataset', type=str, default='mnist')
    parser.add_argument('--pretrain_path', type=str, default='data/ae_mnist.pkl')
    parser.add_argument('--gamma', default=0.1, type=float, help='coefficient of clustering loss')
    parser.add_argument('--update_interval', default=1, type=int)
    parser.add_argument('--tol', default=0.001, type=float)
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    print("use cuda: {}".format(args.cuda))
    device = torch.device("cuda" if args.cuda else "cpu")

    if args.dataset == 'mnist':
        args.pretrain_path = 'data/ae_mnist.pkl'
        args.n_clusters = 10
        dataset = MnistDataset()
    print(args)
    train_idec()
