import numpy as np
from scipy.spatial.distance import pdist, squareform
from utils import MnistDataset, cluster_acc


def getDistCut(distList, distPercent):
    position = round(len(distList) * distPercent / 100)
    distList = sorted(distList)
    return distList[position]


def getRho(n,distMatrix,distCut):
    rho = np.zeros(n)
    for i in range(n-1):
        for j in range(i+1, n):
            rho[i] = rho[i] + np.exp(-(distMatrix[i, j] / distCut) ** 2)
            rho[j] = rho[j] + np.exp(-(distMatrix[i, j] / distCut) ** 2)
    # rho = np.array([item / max(rho) for item in rho])
    return rho

def getGammaLeader(n, rho, distMatrix):
    Delta = np.zeros(n, dtype=float)
    Leader = np.ones(n, dtype=int) * (-1)
    OrdRhoIndex = np.flipud(np.argsort(rho))
    maxdist = 0
    for i in range(n):
        if distMatrix[OrdRhoIndex[0], i] > maxdist:
            maxdist = distMatrix[OrdRhoIndex[0], i]
    Delta[OrdRhoIndex[0]] = maxdist

    '''获取密度最大点以外样本的Delta和Leader'''
    for i in range(1, n):
        mindist = np.inf
        minindex = -1
        for j in range(i):
            if distMatrix[OrdRhoIndex[i], OrdRhoIndex[j]] < mindist:
                mindist = distMatrix[OrdRhoIndex[i], OrdRhoIndex[j]]
                minindex = OrdRhoIndex[j]
        Delta[OrdRhoIndex[i]] = mindist
        Leader[OrdRhoIndex[i]] = minindex
    Gamma = Delta * rho
    OrdGammaIndex = np.flipud(np.argsort(Gamma))
    return Gamma, OrdGammaIndex, OrdRhoIndex, Leader


def getInformationBlock(n, OrdGammaIndex, OrdRhoIndex, Leader, blockNum):
    clusterIndex = np.ones(n, dtype=int) * (-1)
    for j in range(blockNum):  ####直接给聚类中心点类簇标记{0,1}
        clusterIndex[OrdGammaIndex[j]] = j
    for i in range(1, n):
        if clusterIndex[OrdRhoIndex[i]] == -1:
            clusterIndex[OrdRhoIndex[i]] = clusterIndex[Leader[OrdRhoIndex[i]]]
    return clusterIndex

def Combinations(L, k):
    """List all combinations: choose k elements from list L"""
    n = len(L)
    result = []  # To Place Combination result
    for i in range(n - k + 1):
        if k > 1:
            newL = L[i + 1:]
            Comb, _ = Combinations(newL, k - 1)
            for item in Comb:
                item.insert(0, L[i])
                result.append(item)
        else:
            result.append([L[i]])
    return result, len(result)

def fit(x, distPercent, blockNum, pro, y_labels,idxx):
    n = len(x)
    distList = pdist(x, metric='euclidean')
    distMatrix = squareform(distList)
    distCut = getDistCut(distList, distPercent)
    print(distCut)
    rho = getRho(n, distMatrix, distCut)
    Gamma, OrdGammaIndex, OrdRhoIndex, Leader = getGammaLeader(n, rho, distMatrix)
    ordgamm = OrdGammaIndex[1:pro]
    cen = OrdGammaIndex[0]
    val = Combinations(ordgamm, blockNum-1)
    nacc = 0
    for i in range(val[1]):
        c = val[0][i]
        c.append(cen)
        OrdGammaIndex = np.array(c)
        clusterIndex = getInformationBlock(n, OrdGammaIndex, OrdRhoIndex, Leader, blockNum)
        Index = clusterIndex[idxx.astype('int64')]
        acc = cluster_acc(y_labels, Index)
        if acc > nacc:
            nacc = acc
            centers = x[OrdGammaIndex[:blockNum]]
            realcl = clusterIndex

    return realcl, centers

